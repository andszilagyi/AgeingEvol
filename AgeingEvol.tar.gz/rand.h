#ifndef RAND_H
#define RAND_H

void seed(long seed);
long randl(long num); // random long integer between 0 and n-1; n must be larger than 0
double randd(void); // random double between 0 and 1

#endif // RAND_H
