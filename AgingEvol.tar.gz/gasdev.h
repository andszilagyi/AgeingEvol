#ifndef NRX_GASDEV_H
#define NRX_GASDEV_H

double gasdev_scaled(double scale);

#endif // NRX_GASDEV_H
