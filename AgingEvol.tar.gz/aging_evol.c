#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#include "rand.h"
#include "gasdev.h"

#define N (200) //size of the grid
#define L (100) // total number of loci
#define LF (50) // nunber of fecundity loci
#define LA (L-LF) // number of senescence loci
#define AgeVal (0.01) // proportionality value of senescence
#define pflipfec (0.01)  // per bit flip probability of fecundity allels
#define pflipage (0.01) // per bit flip probability of senescence allels
#define sel_reg (0) // selection regime, 0:directional, 1:stabilizing
#define death_prob_baseline (0.05) // baseline death rate
#define Tfitness (10) // fitness period dilution
#define prec (1.0) // probability of single point recombination
#define fitbase (1.2) // base of fitness
#define SEED (1919) // seed of the random number generator
#define time_steps (10000) // total time steps of the simulation
#define ner (1) // Moore neighbourhood radius
#define print_mod (5) // print grid every Nth step
#define print_grid (0) // making snapshots in every print_mod time steps (0: no, 1:yes)
#define aging_max (0.27) // maximum value of rate of ageing (for visualization)

typedef struct _IND
{
  int G[L];
  long double fitness;
  long double sumagerness;
  int age;
}COMP;

COMP comp[N*N];

int Gtarget[LF],incr, neigh[N*N], neigh_cnt, time, indsetfec[LF], indsetage[LA], stabtarget[LF];
long double fitness[N*N];

void piksrt(int n, int *arr)
{
  int i,j,a;
  
  for (j=0;j<n;j++)
  {
    a=arr[j];
    i=j-1;
    while (i >= 0 && arr[i] > a)
    {
      arr[i+1]=arr[i];
      i--;
    }
    arr[i+1]=a;
  }
}

void fittarget()
{
  int n,pos[LF],num=0;
  
  for(n=0;n<LF;n++)
    pos[n]=0;
  if(incr==1)
  {
    for(n=0;n<LF;n++)
    {
      if(Gtarget[n]==0)
        pos[num++]=n;
    }
    Gtarget[pos[randl(num)]]=1;
    if(num==1)
      incr=0;
  }
  else
  {
    for(n=0;n<LF;n++)
    {
      if(Gtarget[n]==1)
        pos[num++]=n;
    }
    Gtarget[pos[randl(num)]]=0;
    if(num==1)
      incr=1;
    
  }
}


long double aveHD()
{
  int x,i,nu=0;
  long double summ=0.0;
  

  for(x=0;x<N*N;x++)
  {
    if(comp[x].age >= 0)
    {
      nu++;
      for(i=0;i<LF;i++)
      {
        if(sel_reg==0)
        {
          if(Gtarget[i]!=(comp[x].G[indsetfec[i]]))
            summ=summ+1.0;
        }
        if(sel_reg==1)
        {
          if((stabtarget[i])!=(comp[x].G[indsetfec[i]]))
            summ=summ+1.0;
        }        
      }
    }
  }
  
  
  return(summ/((long double)nu));
}

void shuffle(int *array, size_t n)
{
  if(n>1)
  {
    size_t i;
    for(i=0;i<n-1;i++)
    {
      size_t j=i+randl(n-i);
      int t=array[j];
      array[j]=array[i];
      array[i]=t;
    }
  }
}

long double fitnessFunction(int x)
{
  long double fit=0.0;
  int i,ngoodloci=0;
  
  if(sel_reg==0)
  {
    for(i=0;i<LF;i++)
    {
      if(Gtarget[i]==(comp[x].G[indsetfec[i]]))
        ngoodloci++;
    }
    fit=pow(fitbase,(double)ngoodloci);
  }
  
  if(sel_reg==1)
  {
    for(i=0;i<LF;i++)
    {
      if((stabtarget[i])==(comp[x].G[indsetfec[i]]))
        ngoodloci++;
    }
    fit=pow(fitbase,(double)ngoodloci);      
  }
  
  
  return(fit);
}

void init()
{
  int x,i;
  int refset[L];
  
  for(i=0;i<L;i++)
    refset[i]=i;  
  for(i=0;i<10;i++)
    shuffle(refset,L);
  for(i=0;i<LF;i++)
    indsetfec[i]=refset[i];
  for(i=0;i<LA;i++)  
    indsetage[i]=refset[i+LF];    

  piksrt(LF,indsetfec);
  
  for(x=0;x<N*N;x++)
  {
    for(i=0;i<LF;i++)
      comp[x].G[indsetfec[i]]=(int)randl(2);
    for(i=0;i<LA;i++)
      comp[x].G[indsetage[i]]=0;
      
    comp[x].age=(int)(1.0/death_prob_baseline)*randd();
    comp[x].fitness=fitnessFunction(x);
    comp[x].sumagerness=0.0;
    for(i=0;i<LA;i++)
      comp[x].sumagerness+=AgeVal*comp[x].G[indsetage[i]];
  }
  for(i=0;i<LF;i++)
    stabtarget[i]=randl(2);

  for(i=0;i<LF;i++)
    Gtarget[i]=0;
  incr=1;
}

void mutation(int x)
{

  int i;
  
  for(i=0;i<LF;i++)
  {
    if(randd()<pflipfec)
      comp[x].G[indsetfec[i]]=-1*comp[x].G[indsetfec[i]]+1;
  }
  
  for(i=0;i<LA;i++)
  {
    if(randd()<pflipage)  
      comp[x].G[indsetage[i]]=-1*comp[x].G[indsetage[i]]+1;
  }
      
}

void dead_by_age(int x)
{
  long double death_prob;

  death_prob = death_prob_baseline + comp[x].sumagerness * comp[x].age;
  if(randd() < death_prob)
    comp[x].age = -1;
  
}

void neighbours(int x)
{
  int t,row,col;
  int xx,yy;

  col=x%N;
  row=x/N;
  neigh_cnt = 0;
  for(yy = -ner; yy <= ner; yy++)
    for(xx = -ner; xx <= ner; xx++)
    {
      t = ((row+yy+N)%N)*N+(col+xx+N)%N;
      if(t==x)
        continue;  
      if(comp[t].age > 0)
        neigh[neigh_cnt++] = t;
    }
}

void recombine_to_x(int x, int e1, int e2)
{
 int p,i;

  p=randl(L-1)+1;

  for(i=0;i<L;i++)
  {
    if(i<p)
      comp[x].G[i]=comp[e1].G[i];
    else
      comp[x].G[i]=comp[e2].G[i];
  }
  
  comp[x].age=0;
  mutation(x);
  comp[x].fitness=fitnessFunction(x);
  comp[x].sumagerness=0.0;
  for(i=0;i<LA;i++)
    comp[x].sumagerness+=AgeVal*comp[x].G[indsetage[i]];

}

void replicate_to_x(int x, int e1)
{
  int i;
  
  for(i=0;i<L;i++)
    comp[x].G[i]=comp[e1].G[i];
   
  comp[x].age=0;
  mutation(x);
  comp[x].fitness=fitnessFunction(x);
  comp[x].sumagerness=0.0;
  for(i=0;i<LA;i++)
    comp[x].sumagerness+=AgeVal*comp[x].G[indsetage[i]];    
}

void reproduction(int x)
{
  int t,e1=-999,e2=-999;
  long double sum,prop,sumprop;

  neighbours(x);
  if(neigh_cnt == 0) return;
  if(neigh_cnt == 1)
  {    
    if(prec<1.0)
    {
      replicate_to_x(x, neigh[0]);
      return;
    }
    else
      return;
  }
  for(t=0;t<neigh_cnt;t++)
  {
    fitness[t]=comp[neigh[t]].fitness;
  }

  sum=0.0;
  for(t=0;t<neigh_cnt;t++)
    sum+=fitness[t];
  prop=sum*randd();
  sumprop=0.0;
  for(t=0;t<neigh_cnt;t++)
  {
    sumprop+=fitness[t];
    if((prop<=sumprop))
      break;
  }
  e1=neigh[t];

  fitness[t]=0.0;
  sum=0.0;
  for(t=0;t<neigh_cnt;t++)
    sum+=fitness[t];
  prop=sum*randd();
  sumprop=0.0;
  for(t=0;t<neigh_cnt;t++)
  {
    sumprop+=fitness[t];
    if((prop<=sumprop))
      break;
  }
  e2=neigh[t];

  if(randd() < prec)
  {
    if(randd()<0.5)  
      recombine_to_x(x,e1,e2);
    else
      recombine_to_x(x,e2,e1);  
  }
  else
    replicate_to_x(x,e1);
  
}

int printgrid(int timeStep)
{
    char fn[256];
    char fb[N * N * 3];
    int x,y,addr;
    int fade;
    double an;
    snprintf(fn, sizeof(fn), "img.%05d.pnm", timeStep);
    FILE* f = fopen(fn, "wb");
    if(f == NULL) return(-1);
    fprintf(f, "P6\n# %d\n%d %d\n255\n", timeStep, N, N);
    for(y=0;y<N; y++)
      for(x=0;x<N;x++)
      {
        addr = (x+y*N) * 3;
        if(comp[x+y*N].age < 0)
        {
          fb[addr] = 0;
          fb[addr + 1] = 0;
          fb[addr + 2] = 0;
        }else
        {
          an = fmin(comp[x+y*N].sumagerness, aging_max);
          fade = (an / aging_max) * 255;
          fb[addr] = fade;
          fb[addr + 1] = 0;
          fb[addr + 2] = 255 - fade;
        }
      }
    if(fwrite(fb, sizeof(fb), 1, f) != 1)
    {
        fclose(f);
        return(-1);
    }
    fclose(f);
    return(0);
}

void stats(
    long double *avg_fitness,
    long double *alive,
    long double *avg_age,
    long double *avg_agerness,
    long double *min_agerness,
    long double *max_agerness,
    int *num1)
{
  int x;

  *avg_fitness = 0.0;
  *alive = 0;
  *avg_age = 0.0;
  *avg_agerness = 0.0;
  *min_agerness = -1;
  *max_agerness = -1;
  *num1 = 0;
  
  for(x = 0; x < (N*N); x++)
  {
    if(comp[x].age >= 0)
    {
      (*alive)++;
      (*avg_fitness) += comp[x].fitness;
      (*avg_age) += comp[x].age;
      (*avg_agerness) += comp[x].sumagerness;
      if(((*min_agerness) < 0) || (comp[x].sumagerness < (*min_agerness))) (*min_agerness) = comp[x].sumagerness;
      if(((*max_agerness) < 0) || (comp[x].sumagerness > (*max_agerness))) (*max_agerness) = comp[x].sumagerness;
    }
  }
  if((*alive) > 0)
  {
    *avg_fitness /= (*alive);
    *avg_age /= (*alive);
    *avg_agerness /= (*alive);
    *alive /= (long double)(N*N);
  }
  
  for(x=0;x<LF;x++)
    if(Gtarget[x]==1)
      *num1=*num1+1;
}

int main(int argc, char** argv)
{
  int x,nn,num1;
  long double avg_fitness, avg_age, alive, avg_agerness, min_agerness, max_agerness;
  
  seed(SEED);
  init();  

  printf("# time\tave_fitness|\tfrequency of living individulas|\taverage age|\taverage rate of aging|\tminumum rate of aging|\tmaximum rate of aging|\taverage Hamming distance from the actual target|\tnumber of 1s in the target\n");
  for(time=0;time<time_steps;time++)
  {
    if(time%Tfitness==0)
      fittarget();

    for(nn=0;nn<N*N;nn++)
    {
      x=randl(N*N);
      if(comp[x].age>=0)
        dead_by_age(x);
      if(comp[x].age==-1)
        reproduction(x);
    }
    for(x=0;x<N*N;x++)
      if(comp[x].age >= 0)
        comp[x].age++;
    
    if((time % print_mod)==0)
    {
      stats(&avg_fitness, &alive, &avg_age, &avg_agerness, &min_agerness, &max_agerness, &num1);
      printf("%d\t%Le\t%Lf\t%Lf\t%Lf\t%LF\t%LF\t%Lf\t%d\n",
             time, avg_fitness, alive, avg_age, avg_agerness, min_agerness, max_agerness,aveHD(),num1);
      fflush(stdout);
      if(print_grid==1)  
        printgrid(time);
    }
          
  }
  return(0);
}
